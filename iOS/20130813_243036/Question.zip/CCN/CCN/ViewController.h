//
//  ViewController.h
//  CCN
//
//  Created by Ruslan on 25.07.13.
//  Copyright (c) 2013 Ruslan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIScrollView *scroller;

@end

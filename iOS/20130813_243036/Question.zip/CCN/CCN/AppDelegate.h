//
//  AppDelegate.h
//  CCN
//
//  Created by Ruslan on 25.07.13.
//  Copyright (c) 2013 Ruslan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

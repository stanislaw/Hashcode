//
//  CCNTests.m
//  CCNTests
//
//  Created by Ruslan on 25.07.13.
//  Copyright (c) 2013 Ruslan. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface CCNTests : XCTestCase

@end

@implementation CCNTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
